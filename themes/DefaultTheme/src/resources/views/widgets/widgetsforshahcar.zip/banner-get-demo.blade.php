<div class="d-flex align-items-center justify-content-center flex-column my-3 w-100">

<div class="Option_Card_Title mb-2 container">
        <div class="Option_Card_Right_Line"></div>
        <h2 class="Option_Card_Center_Line">{{$widget->option('title1')}}</h2>
        <div class="Option_Card_Left_Line"></div>
</div>

<div class="Banner_Div d-flex align-items-center justify-content-center w-100 my-4 my-lg-5" data-aos="fade-up" data-aos-duration="1000">

    <a href="{{env('APP_URL').'/'.$widget->option('link1')}}" class="d-flex align-items-center justify-content-center w-100 h-100">
        <img src="{{$widget->option('image')}}" alt="" class="w-100 h-100">
    </a>

</div>

</div>
