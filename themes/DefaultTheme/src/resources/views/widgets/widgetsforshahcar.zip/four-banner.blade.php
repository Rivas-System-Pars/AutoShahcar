<div class="mx-auto banners_container-quadruple my-3">
        <div class="d-flex align-items-center justify-content-center flex-wrap banners_container-quadruple_inner">
            <div class="the_banner">
                <a href="{{env('APP_URL').''.$widget->option('link1')}}" class="d-flex align-items-center justify-content-center w-100 h-100">
                    <img class="the_banner-img" src="{{env('APP_URL').''.$widget->option('image1')}}"
                        alt="">
                </a>
            </div>
            <div class="the_banner">
                <a href="{{env('APP_URL').''.$widget->option('link2')}}" class="d-flex align-items-center justify-content-center w-100 h-100">
                    <img class="the_banner-img" src="{{env('APP_URL').''.$widget->option('image2')}}"
                        alt="">
                </a>
            </div>
            <div class="the_banner">
                <a href="{{env('APP_URL').''.$widget->option('link3')}}" class="d-flex align-items-center justify-content-center w-100 h-100">
                    <img class="the_banner-img" src="{{env('APP_URL').''.$widget->option('image3')}}"
                        alt="">
                </a>
            </div>
            <div class="the_banner">
                <a href="{{env('APP_URL').''.$widget->option('link4')}}" class="d-flex align-items-center justify-content-center w-100 h-100">
                    <img class="the_banner-img" src="{{env('APP_URL').''.$widget->option('image4')}}"
                        alt="">
                </a>
            </div>
        </div>
    </div>